%% Script to normalize and save the result
% add the path of this function and run it form the directory where is the
% TS

clear
clc

load datainput.txt

inpNorm = mapminmax1(datainput',-0.7,0.7);
inpNorm = inpNorm';

%cd('txtFiles')
save ('dataInputN.txt', 'inpNorm', '-ascii', '-tabs');